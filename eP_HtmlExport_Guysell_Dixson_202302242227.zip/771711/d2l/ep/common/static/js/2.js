/*
NameSpacing stuff
*/

D2L.eP = {};
D2L.eP.ImportExport = {};
D2L.eP.Objects = {};
D2L.eP.Common = {};
D2L.eP.Common.Sharing = {};

